package com.springboot.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.springboot.model.Question;
import com.springboot.repository.QuestionRepository;
@Service
@Transactional
public class QuestionService {
	   @Autowired
	    private QuestionRepository repo;
	     
	   public Question save(Question question) {
			return repo.save(question);
		}

		
		public Optional<Question> getById (int id) {
			return repo.findById( id);
		}

		public List<Question> getAll() {
			return repo.findAll();
		}
		public Question get(Integer id) {
	        return repo.findById(id).get();
	    }

		public void delete(int  id) {
			repo.deleteById(id);
		}
}