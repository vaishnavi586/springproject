package com.springboot.controller;

import java.util.*;


import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
 
import org.springframework.web.bind.annotation.*;

import com.springboot.model.Question;
import com.springboot.service.QuestionService;

@RestController
@RequestMapping("/questions")
public class QuestionController {
	@Autowired
	private QuestionService service;
	
	
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<Question>> getAllQuestions() {
		List<Question> questions = service.getAll();
		if (questions.isEmpty()) {
			
			return new ResponseEntity<List<Question>>(HttpStatus.NO_CONTENT);
		}
		
		return new ResponseEntity<List<Question>>(questions, HttpStatus.OK);
	}
	
	
	@RequestMapping(value ="/{id}", method = RequestMethod.GET)
	public ResponseEntity<Question> get(@PathVariable Integer id) {
	    try {
	    	Question question = service.get(id);
	        return new ResponseEntity<Question>(question, HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<Question>(HttpStatus.NOT_FOUND);
	    }      
	}

	
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Question> addQuestion(@RequestBody Question question) {
		service.save(question);
		;
		return new ResponseEntity<Question>(question, HttpStatus.CREATED);
	}
	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<Void> updateQuestion(@RequestBody Question question) {
		Optional<Question> existingQue = service.getById(question.getId());
		if (existingQue == null) {
			
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		} else {
			service.save(question);
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
	}
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteQuestion(@PathVariable("id") Integer id) {
		Optional<Question> question = service.getById(id);
		if (question == null) {
			
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		} else {
			service.delete(id);
			
			return new ResponseEntity<Void>(HttpStatus.GONE);
		}
	}
	
	
}
